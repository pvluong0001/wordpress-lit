<?php
/*
 * Plugin Name: Lit
 * Plugin URI:
 * Description: Lit
 * Author: Lit
 * Version: 1.0
 */

require_once __DIR__ . "/Lit.php";
$litPlugin = new Lit();